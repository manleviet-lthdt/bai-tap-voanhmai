﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class DUYET
    {
        public string Ten { get; set; }
        abstract public bool Duyettactu(Grid grid);
        public DUYET(string t)
        { Ten = t; }
    }
}
