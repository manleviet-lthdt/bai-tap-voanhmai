﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class DUYETngaunhien : DUYET 
    {
        public DUYETngaunhien()
        { }
        public override bool Duyettactu(ref Grid grid )
        { }
        public override void Sapxep(ref Grid grid , Grid  t)
        {
        
        }
        public override void Sapxepkep (ref Grid grid , Grid  t) { }
    }
}
