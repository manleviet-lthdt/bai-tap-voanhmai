﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Multi_cell:Cell
    {
        public List<Agent> list;
        public Multi_cell ()
        { list = new List<Agent>(); }
        public override void Taotactu(Agent t)
        {
            list.Add(t);
        }
        public override void Xoatactu(Agent t)
        {
            list.Remove(t);
        }
        public override List<Agent> Demtactu()
        { return list; }
    }
}
