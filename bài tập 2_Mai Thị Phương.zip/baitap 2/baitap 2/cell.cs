﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Cell 
    {
        public Cell ()
        { }
        public virtual void Taotactu()
        { }
        public virtual void Xoatactu()
        { }
        public virtual List<Agent > Demtactukep ()
        { return null; }
        public virtual Agent  Demtactudon()
        { return null; }


    }
}
