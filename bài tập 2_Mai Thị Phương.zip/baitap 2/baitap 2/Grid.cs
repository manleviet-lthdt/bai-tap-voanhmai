﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Grid 
    {
        public Cell[,] mang;
        public Duyet Kieuduyet;
        private int hang;
        private int cot;
        public int Hang
        {
            get { return hang; }
            set { hang = value; }
        }
        public int Cot
        {
            get { return cot; }
            set { cot = value; }
        }
        public Cell this[int h,int c]
        {
            get { return mang[h, c]; }
            set { mang[h, c] = value; }
        }
        public Grid (int hang, int cot, Duyet kieuduyet)
        {
            mang = new Cell[hang, cot];
            Kieuduyet = Kieuduyet;
            Hang = hang;
            Cot = cot;
        }
    }
}
