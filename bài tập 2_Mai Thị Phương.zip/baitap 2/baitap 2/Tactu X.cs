﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Agent_X : Agent
    {
        public Agent_X()
        { }
        public Agent_X (double cshp)
            : base (cshp)
        { }
    }
}
