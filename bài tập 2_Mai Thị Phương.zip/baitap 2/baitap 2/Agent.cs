﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Agent
    {
        public int Soluong { get; set; }
        public double Chisohanhphuc { get; set; }
        public Agent()
        { }
        public Agent (double cshp,int sl)
        { Chisohanhphuc = cshp;
            Soluong = sl;
        }

    }
}
