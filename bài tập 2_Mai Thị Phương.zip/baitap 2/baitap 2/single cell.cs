﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap_2
{
    class Single_cell:Cell
    {
        public Agent agent;
        public Single_cell()
        {
        }
        public Single_cell(Agent tt):base()
        { agent = tt; }
        public override void Taotactu(Agent t)
        {
            agent = t;
  
        }
        public override Agent Demtactudon()
        {
            return agent;
        }
        public override void Xoatactu()
        {
            agent = null;
        }

    }
}
