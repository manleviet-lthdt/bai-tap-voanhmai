﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    abstract  class DUYET
    {

        public String ten { get; set; }
        public int solanduyet { get; set; }
        public DUYET ( string t, int sld )
        {
            ten = t;
            solanduyet = sld;
        }

         public abstract bool DuyetTacTu(ref LUOI luoi);
        public DUYET ()
        {

        }

    }
     

}
