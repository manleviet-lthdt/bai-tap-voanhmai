﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class O : AGENT
    {
        double t; //t la chisohanhphuc
        public O (string ten, int soluong, double chisohanhphuc)
            : base (ten, soluong, chisohanhphuc)
             { }
        public O ()
        {
            Console.WriteLine(" in ra vi tri moi cua tac tu");

        }

    }
}

