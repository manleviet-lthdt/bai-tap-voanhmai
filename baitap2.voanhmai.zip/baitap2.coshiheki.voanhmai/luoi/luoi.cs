﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    abstract class LUOI
    {
        public string Ten { get; set; }
        public int SoLuongTacTu { get; set; }
        public string ViTri { get; set; }
        public LUOI(string t, int sl, string vt)
        {
            Ten = t;
            SoLuongTacTu = sl;
            ViTri = vt;
        }
        public abstract string Ochuatactu();
        public override string ToString()
        {
            return string.Format("-{0}-{1}-{2}", Ten, SoLuongTacTu, ViTri);

        }
    }
}
