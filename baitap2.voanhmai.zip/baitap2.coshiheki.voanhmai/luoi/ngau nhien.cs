﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class ngau_nhien: DUYET
    {
        public ngau_nhien (string ten, int solanduyet)
            : base (ten, solanduyet)
        { }
          
    }
}
