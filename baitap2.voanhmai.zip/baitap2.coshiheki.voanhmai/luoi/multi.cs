﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class MULTI : CELL
    {
        public MULTI(string Ten, string ViTri)
            : base (Ten, ViTri)
            { }
       public MULTI ()
        {
            Console.WriteLine(" in ra agent");
        }
    }
}
