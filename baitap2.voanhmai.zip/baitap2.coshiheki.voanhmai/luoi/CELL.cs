﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    abstract class CELL
    {
        public string Ten { get; set; }
        public string ViTri { get; set; }
        public CELL(string t, string vt)
        {
            Ten = t;
            ViTri = vt;
        }
        public abstract int loạitactu();
        public override string ToString()
        {
            return string.Format("-{0}-{1}", Ten, ViTri);
        }
    }
}
