﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class tuantu : DUYET
    {
        public tuantu (string ten, int solanduyet)
            :base ( ten, solanduyet)
        { }
    }
}
