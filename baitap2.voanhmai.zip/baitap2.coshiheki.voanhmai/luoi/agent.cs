﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    abstract class AGENT
    {
        public string ten { get; set; }
        public int soluong { get; set; }
        public double chisohanhphuc { get; set; }
        public AGENT(string t, int sl, double cs)
        {
            ten = t;
            soluong = sl;
            chisohanhphuc = cs;
        }
        public abstract string hoatdong();
        public override string ToString()
        {
            return string.Format("{0}-{1}-{2}", ten, soluong, chisohanhphuc);

        }
}
    }
