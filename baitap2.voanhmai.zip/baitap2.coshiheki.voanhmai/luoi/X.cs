﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class X : AGENT
    { public X (string ten, int soluong, double chisohanhphuc)
            : base(ten, soluong, chisohanhphuc)
            { }
        public X ()
        {
            Console.WriteLine(" in ra vi tri moi cua tac tu");
        }
}
}
