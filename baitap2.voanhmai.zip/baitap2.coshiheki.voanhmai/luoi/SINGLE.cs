﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace luoi
{
    class SINGLE : CELL
    {
        public SINGLE(string Ten, string ViTri)
            : base(Ten, ViTri)
        { }
        public SINGLE ()
        {
            Console.WriteLine(" in ra  tat ca agent");
        }
    }
}

